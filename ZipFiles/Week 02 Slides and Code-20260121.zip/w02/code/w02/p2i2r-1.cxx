#include <iostream>

int main()
{
  using namespace std;

  int ar[] = { 1, 2, 3, 4, 5 };

  for (int i=0; i != 5; ++i)
    cout << ar[i] << ' ';
  cout << '\n';
}
