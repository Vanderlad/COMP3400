[[deprecated]] void foo() { }
[[deprecated("bar() will be removed in next release")]] void bar() { }
void foo(int) { }
void bar(int) { }
