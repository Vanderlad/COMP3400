int main()
{
  [[maybe_unused]] int i;
}
