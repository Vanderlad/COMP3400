#ifndef OUTPUT_HXX_
#define OUTPUT_HXX_
  #define OUT(S) std::cout << S << this << ' ' << '\n'
  #define OUT2(S,A) std::cout << S << this << ' ' << A << '\n'
#endif // #ifndef OUTPUT_HXX_
