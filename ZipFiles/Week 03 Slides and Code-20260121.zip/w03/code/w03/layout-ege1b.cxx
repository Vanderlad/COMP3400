struct D_data_members 
{
  int z; int a; // D::A
  int b; // D::B
  int y; int c; // D::C
  int d; // D
};
