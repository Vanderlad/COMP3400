struct W { };
struct X : W { int x; };
struct Y : X { int y; };
struct Z : Y { int z; };
