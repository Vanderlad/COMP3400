// struct W from previous example
struct W2 : W
{
  int w2;
  void f() override; // F5
  void f(long double d); // F6
};
