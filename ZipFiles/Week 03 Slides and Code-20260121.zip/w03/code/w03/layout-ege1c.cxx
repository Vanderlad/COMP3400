D d;
d.z = 1;
d.a = 2;
d.y = 3;
