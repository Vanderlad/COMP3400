struct X 
{
  int x;
  virtual void f();
  virtual void g(char);
  virtual void h(float);
};
