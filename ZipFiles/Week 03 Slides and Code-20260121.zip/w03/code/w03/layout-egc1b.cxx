struct Z_mem_layout
{ 
  int x; 
  int y; 
  int z; 
};
