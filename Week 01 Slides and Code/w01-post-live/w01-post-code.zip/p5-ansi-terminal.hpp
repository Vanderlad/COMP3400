#ifndef p5_ansi_terminal_hpp_
#define p5_ansi_terminal_hpp_

//=============================================================================

#include <ostream>      // for std::ostream
#include <sstream>      // for std::ostringstream
#include <string>       // for std::string
#include <type_traits>  // for std::underlying_type_t

//=============================================================================

namespace ansi_terminal {

//
// ANSI terminal colour code...
// e.g., see https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
//
enum class colour : unsigned char
{
  black = 30, red = 31, green = 32, yellow = 33,
  blue = 34, magenta = 35, cyan = 36, white = 37,

  bright_black = black+60, gray = bright_black,
  bright_red = red+60, bright_green = green+60, bright_yellow = yellow+60,
  bright_blue = blue+60, bright_magenta = magenta+60,
  bright_cyan = cyan+60, bright_white = white+60
};

inline std::ostream& reset(std::ostream& os)
{
  os << "\x1b[0m";
  return os;
}

class set
{
private:
  colour c_;

public:
  explicit set(colour c) : 
    c_{c}
  {
  }

  friend std::ostream& operator<<(std::ostream& os, set const& s)
  {
    // colour is an enum class so obtain the underlying type of colour
    // and store that in a variable that is converted to be an integer
    // value (and not a char) using unary +...
    auto const c_value{ 
      +static_cast<std::underlying_type_t<colour>>(s.c_) 
    };

    os << "\x1b[";
    if (c_value < 60)
      // colour is low intensity...
      os << c_value << 'm';
    else
      // colour is high intensity...
      // (most terminals require using 1m instead of + 60 with the
      // low-intensity value so this is done here)
      os << c_value-60 << ";1m";
    return os;
  }
};

// Although unused in this program, this demonstates how to use reset() to 
// output its output as a std::string. (This is suitably efficient since
// the stream is a buffer, reset() writes to such, and that is turned into
// a string at the end so if moves are done within these calls, this should 
// avoid unnecessary memory allocations, etc.) That said, stream I/O 
// functions cannot be constexpr so this shouldn't be done if one needs 
// constexpr functions that return std::string values for use at compile-time.
inline std::string reset_string()
{
  std::ostringstream buf;
  buf << reset;
  return buf.str();
}

// Although unused in this program, similar to reset_string(), this function 
// gets the colour set as a std::string.
inline std::string set_string(colour c)
{
  std::ostringstream buf;
  buf << set(c);
  return buf.str();
}

} // namespace ansi_terminal

//=============================================================================

#endif // #ifndef p5_ansi_terminal_hpp_
