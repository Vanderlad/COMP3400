//
// Relative to p3.cpp, this program highlights the digits of pi 
// using colour to make it much easier to see if the digits of pi
// are correct or not.
//

#include <algorithm>    // for std::ranges::mismatch
#include <cmath>        // for std::sqrt
#include <cstddef>      // for std::size_t
#include <format>       // for std::format_to
#include <generator>    // for std::generator
#include <iostream>     // for std::cout
#include <iterator>     // for std::back_inserter
#include <numbers>      // for std::numbers
#include <optional>     // for std::optional
#include <print>        // for std::println
#include <sstream>      // for std::ostringstream
#include <string>       // for std::string
#include <string_view>  // for std::string_view

#include "p4-ansi-terminal.hpp"

std::generator<double> first_form()
{
  using std::sqrt;

  double value = 1.0 / sqrt(3.0);
  co_yield value;

  for (;;)
  {
    value = (sqrt(value*value + 1.0) - 1.0) / value;
    co_yield  value;
  }
}

std::generator<double> second_form()
{
  using std::sqrt;

  double value = 1.0 / sqrt(3.0);
  co_yield value;

  for (;;)
  {
    value = value / (sqrt(value*value+1.0)+1.0);
    co_yield value;
  }
}

double form_to_pi(std::size_t i, double value)
{
  return value * std::pow(2,i) * 6.0;
}

std::string pi_coloured_diff_string(
  double value,
  ansi_terminal::colour same_colour,
  ansi_terminal::colour diff_colour
)
{
  using namespace ansi_terminal;

  // C++ in <numbers> defines pi... use it to know
  // the correct value of pi,
  //   e.g., std::numbers::pi_v<double>
  // but use std::format_to() to convert such to a string...
  std::string correct_pi;
  std::format_to(
    std::back_inserter(correct_pi), "{}", std::numbers::pi_v<double>
  );

  // Convert value to a string...
  std::string value_as_string;
  std::format_to(std::back_inserter(value_as_string), "{}", value);

  // Now perform a diff between the two strings inserting the 
  // appropriate colour (based on whether or not the strings match).
  // (This is only done up until the first mismatch.)
  auto [pos1, pos2] = std::ranges::mismatch(correct_pi,value_as_string); 
  
  std::ostringstream buf;
  // output correct digits with same_colour and reset colour...
  buf 
    << set_string(same_colour)
    << std::string_view(correct_pi.begin(), pos1)
    << reset_string()
  ;
  // output incorrect digits with diff_colour and reset colour...
  buf
    << set_string(diff_colour)
    << std::string_view(pos2, value_as_string.end())
    << reset_string()
  ;
  return buf.str();
}

std::string coloured_string(auto value, ansi_terminal::colour c)
{
  using namespace ansi_terminal;

  std::ostringstream buf;
  buf << set_string(c);
  std::format_to(std::ostream_iterator<char>(buf), "{}", value);
  buf << reset_string();
  return buf.str();
}


int main()
{
  using namespace std;
  using namespace ansi_terminal;

  auto f1 = first_form();
  auto f1it = f1.begin();

  auto f2 = second_form();
  auto f2it = f2.begin();

  //
  // Instead of using std::cout, std::println() is used to output
  // the numbers below.
  //
  // Also notice form_to_pi() is called in this program. (The program
  // presented in class did not call this function so the values
  // output were incorrect.)
  //
  for (std::size_t i=0; i != 30; ++i, ++f1it, ++f2it)
    std::println("{} {} {}", 
      // output i in bright blue...
      coloured_string(i, colour::bright_blue), 
      // output correct pi digits in bright yellow and incorrect 
      // ones in red...
      pi_coloured_diff_string(
        form_to_pi(i,*f1it), colour::bright_yellow, colour::red
      ), 
      pi_coloured_diff_string(
        form_to_pi(i,*f2it), colour::bright_yellow, colour::red
      )
    );
  std::cout << '\n';
}

