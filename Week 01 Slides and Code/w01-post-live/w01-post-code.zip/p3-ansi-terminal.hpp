#ifndef p3_ansi_terminal_hpp_
#define p3_ansi_terminal_hpp_

//=============================================================================

#include <sstream>    // for std::ostringstream
#include <string>     // for std::string
#include <type_traits>  // for std::underlying_type_t

//=============================================================================

namespace ansi_terminal {

//
// ANSI terminal colour code...
// e.g., see https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
//
enum class colour : unsigned char
{
  black = 30, red = 31, green = 32, yellow = 33,
  blue = 34, magenta = 35, cyan = 36, white = 37,

  bright_black = black+60, gray = bright_black,
  bright_red = red+60, bright_green = green+60, bright_yellow = yellow+60,
  bright_blue = blue+60, bright_magenta = magenta+60,
  bright_cyan = cyan+60, bright_white = white+60
};

inline std::string reset_string()
{
  return "\x1b[0m";
}

inline std::string set_string(colour c)
{
  // colour is an enum class so obtain the underlying type of colour
  // and store that in a variable that is converted to be an integer
  // value (and not a char) using unary +...
  auto const c_value{ 
    +static_cast<std::underlying_type_t<colour>>(c) 
  };

  // ostringstream is used to compute a string. It is a stream that
  // writes to a string and then one calls its .str() member
  // function to get the string generated..
  std::ostringstream buf;
  buf << "\x1b[";
  if (c_value < 60)
    // colour is low intensity...
    buf << c_value << 'm';
  else
    // colour is high intensity...
    // (most terminals require using 1m instead of + 60 with the
    // low-intensity value)
    buf << c_value-60 << ";1m";
  return buf.str();
}

} // namespace ansi_terminal

//=============================================================================

#endif // ifndef p3_ansi_terminal_hpp_
