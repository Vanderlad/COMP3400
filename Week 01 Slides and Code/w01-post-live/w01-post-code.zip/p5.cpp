//
// Relative to p4.cpp, this program sets the width of the
// columns output to be more readable (and fancy), e.g., see:
//   * https://en.cppreference.com/w/cpp/utility/format/format_to.html
//   * https://en.cppreference.com/w/cpp/io/println.html
// The format specification syntax and rules are on this page:
//   * https://en.cppreference.com/w/cpp/utility/format/spec.html
//

#include <algorithm>    // for std::ranges::mismatch
#include <concepts>     // for std::integral
#include <cmath>        // for std::sqrt
#include <cstddef>      // for std::size_t
#include <format>       // for std::format_to
#include <generator>    // for std::generator
#include <iostream>     // for std::cout
#include <iterator>     // for std::back_inserter
#include <limits>       // for std::numeric_limits
#include <numbers>      // for std::numbers
#include <optional>     // for std::optional
#include <print>        // for std::println
#include <sstream>      // for std::ostringstream
#include <string>       // for std::string
#include <string_view>  // for std::string_view

#include "p5-ansi-terminal.hpp"

std::generator<double> first_form()
{
  using std::sqrt;

  double value = 1.0 / sqrt(3.0);
  co_yield value;

  for (;;)
  {
    value = (sqrt(value*value + 1.0) - 1.0) / value;
    co_yield  value;
  }
}

std::generator<double> second_form()
{
  using std::sqrt;

  double value = 1.0 / sqrt(3.0);
  co_yield value;

  for (;;)
  {
    value = value / (sqrt(value*value+1.0)+1.0);
    co_yield value;
  }
}

double form_to_pi(std::size_t i, double value)
{
  return value * std::pow(2,i) * 6.0;
}

std::string pi_coloured_diff_string(
  double value,
  ansi_terminal::colour same_colour,
  ansi_terminal::colour diff_colour
)
{
  using namespace ansi_terminal;
 
  // pi is being output so assume max_digits10 + 1 (decimal point)
  std::size_t const width = std::numeric_limits<double>::max_digits10;

  // C++ in <numbers> defines pi... use it to know
  // the correct value of pi,
  //   e.g., std::numbers::pi_v<double>
  // but use std::format_to() to convert such to a string...
  std::string correct_pi;
  std::format_to(
    std::back_inserter(correct_pi), "{:>{}.{}f}", 
    std::numbers::pi_v<double>, 
    width+2, // width (i.e., precision + 2 (i.e., "3."))
    width // i.e., precision
  );

  // Convert value to a string...
  std::string value_as_string;
  std::format_to(std::back_inserter(value_as_string), "{:>{}.{}f}", 
    value, 
    width+2, // width (i.e., precision + 2 (i.e., "3."))
    width // i.e., precision
  );

  // Now perform a diff between the two strings inserting the 
  // appropriate colour (based on whether or not the strings match).
  // (This is only done up until the first mismatch.)
  auto [pos1, pos2] = std::ranges::mismatch(correct_pi,value_as_string); 
  
  std::ostringstream buf;
  // output correct digits with same_colour and reset colour...
  buf 
    << set(same_colour)
    << std::string_view(correct_pi.begin(), pos1)
    << reset
  ;
  // output incorrect digits with diff_colour and reset colour...
  buf
    << set(diff_colour)
    << std::string_view(pos2, value_as_string.end())
    << reset
  ;
  return buf.str();
}

template <typename Value>
requires std::integral<Value>
std::string coloured_decimal_string(
  Value const& value, 
  ansi_terminal::colour c,
  std::optional<size_t> opt_width = std::nullopt
)
{
  using namespace ansi_terminal;
  std::size_t const width = 
    [&]() -> size_t
    {
      if (opt_width)
        return *opt_width;
      else
      {
        if (std::numeric_limits<Value>::digits10 == 0)
          return std::numeric_limits<Value>::max_digits10;
        else
          return std::numeric_limits<Value>::digits10;
      }
    }()
  ;
  std::ostringstream buf;
  buf << set_string(c);
  std::format_to(std::ostream_iterator<char>(buf), "{:>{}d}", value, width);
  buf << reset_string();
  return buf.str();
}


int main()
{
  using namespace std;
  using namespace ansi_terminal;

  auto f1 = first_form();
  auto f1it = f1.begin();

  auto f2 = second_form();
  auto f2it = f2.begin();

  for (std::size_t i=0; i != 30; ++i, ++f1it, ++f2it)
    std::println("{} {} {}", 
      // output i in bright blue...
      coloured_decimal_string(i, colour::bright_blue),

      // output correct pi digits in bright yellow and incorrect 
      // ones in red...
      pi_coloured_diff_string(
        form_to_pi(i,*f1it), colour::bright_white, colour::gray
      ), 
      pi_coloured_diff_string(
        form_to_pi(i,*f2it), colour::bright_white, colour::gray
      )
    );
  std::cout << '\n';
}

