#include <cmath>
#include <cstddef>
#include <generator>
#include <iostream>
#include <print>

//
// Two forms to compute pi per:
//   * https://en.wikipedia.org/wiki/Floating-point_arithmetic#Minimizing_the_effect_of_accuracy_problems
// (Scroll down to t0, first form, and second form.)
//
// This program computes pi (i.e., 3.14) in two ways:
//   * first form is numerically unstable (notice the values output get 
//     better and then all accuracy is eventually lost)
//   * second form is numerically stable (notice the values output 
//     increasingly get better as each value is calculated)
//

std::generator<double> first_form()
{
  using std::sqrt;

  double value = 1.0 / sqrt(3.0);
  co_yield value;

  for (;;)
  {
    value = (sqrt(value*value + 1.0) - 1.0) / value;
    co_yield  value;
  }
}

std::generator<double> second_form()
{
  using std::sqrt;
  
  double value = 1.0 / sqrt(3.0);
  co_yield value;

  for (;;)
  {
    value = value / (sqrt(value*value+1.0)+1.0);
    co_yield value;
  }
}

double form_to_pi(std::size_t i, double value)
{
  return value * std::pow(2,i) * 6.0;
}

int main()
{
  using namespace std;

  auto f1 = first_form();
  auto f1it = f1.begin();

  auto f2 = second_form();
  auto f2it = f2.begin();

  for (std::size_t i=0; i != 30; ++i, ++f1it, ++f2it)
    std::println("{} {} {}", i, form_to_pi(i,*f1it), form_to_pi(i,*f2it));
  std::cout << '\n';
}

