#include <iostream>

constexpr unsigned long long fib(unsigned long long n)
{
  return n > 1 ? fib(n-1)+fib(n-2) : 1;
}

int main()
{
  auto constexpr result = fib(28);
  std::cout << result << std::endl;
}
