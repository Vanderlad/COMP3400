auto func1() -> double; // function prototype w/suffix return

auto func2(int i, double d) -> float
{
  return i + d;
}
