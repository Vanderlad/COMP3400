#include <iostream>
#include <string>

using namespace std;

int main()
{
  int i; double d; string s;
  cin >> i >> d >> s;
  cout << s << ',' << i << ',' << d << '\n';
}
