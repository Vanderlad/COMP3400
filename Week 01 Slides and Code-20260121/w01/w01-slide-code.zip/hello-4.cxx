#include <iostream>

int main()
{
  using namespace std;
  cout << "Hello World!\n";
}
