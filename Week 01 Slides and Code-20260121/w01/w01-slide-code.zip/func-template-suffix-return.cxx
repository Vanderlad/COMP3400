template <typename T, typename U>
auto my_func(T t, U u) -> 
  decltype(t+u) // return type is whatever type t+u is
{
  return t+u;
}
