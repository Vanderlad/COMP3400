auto func2(int i, double d)
{
  return i + d; // deduced return type is double
}
