#include <iostream>

int main()
{
  // When cout is used w/o qualification, get it from std...
  using std::cout;  
  cout << "Hello World!\n";
}
