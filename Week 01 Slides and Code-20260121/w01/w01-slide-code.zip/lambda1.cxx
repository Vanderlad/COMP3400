[](int a, float f) // this is a lambda function with two parameters
{
  return a + f + 5.3; // return type is deduced to be double
}
